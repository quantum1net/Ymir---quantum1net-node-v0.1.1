Quantum1Net v0.01 Ymir

Copyright (c) 2019 Quantum1Net 


Intro
-----
Quantum1Net is a fully decentralized Internet 
Service Platform that uses peer-to-peer technology 
and an electronic cash system (cryptocurrency).  
  
It's completely decentralized with no central server or 
central authority.

Operating Systems
---------------
Linux/OSX:

Windows:


Setup
----

Unpack the files and run quantum1net-node-win.exe on windows, 
or ./quantum1net-node-osx
or ./quantum1net-node-lin

The software automatically finds other nodes to connect to. You should set 
your firewall to forward port 6666 to the computer running the node so 
you can receive incoming connection, otherwise the nodes you can connect too will be limited.

input 'help' for instructions


and keep the program open. it runs at idle priority. Your node will be relaying 
transaction data across the network.






